# Red Hat Third-Party Wrapper

1. Copy the approved vendor JAR to:

   libs/redhat.jar

2. Update `gradle.properties` with the real group, artifact, version, and filename.

3. Build:

   gradlew.bat clean build

   or, when your organization provides Gradle directly:

   gradle clean build

4. Expected output:

   build/libs/redhat-1.0.0.jar

## CloudBees parameters

JAR_NAME       = redhat
JAR_VERSION    = 1.0.0
GroupID_Name   = com.company.thirdparty
Application_Name = REDHAT_THIRD_PARTY
Service_Name     = redhat-third-party
Git_Branch       = main

## Consumer

implementation "com.company.thirdparty:redhat:1.0.0"

## Wrapper

Generate once with the organization-approved Gradle version:

gradle wrapper --gradle-version 8.5

Then commit gradlew, gradlew.bat, gradle-wrapper.jar, and gradle-wrapper.properties.
