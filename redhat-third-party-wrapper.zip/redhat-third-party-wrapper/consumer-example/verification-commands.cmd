@echo off
gradlew.bat clean build --refresh-dependencies
gradlew.bat dependencyInsight --dependency redhat --configuration runtimeClasspath
