Place the approved vendor JAR here. Default expected name: redhat.jar
